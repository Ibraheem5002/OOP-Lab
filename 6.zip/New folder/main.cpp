#include "Employee.cpp"

int main()
{
    Employee Employee1;

    Employee1.get_data();
    Employee1.Salary_After_Tax();
    Employee1.Update_Tax_Percentage();
}