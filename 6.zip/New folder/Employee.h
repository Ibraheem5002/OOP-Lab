#include <iostream>
using namespace std;

class Employee
{
private:
    string Name;
    double Salary;
    float Tax_Percentage;

public:
    void get_data();

    void Salary_After_Tax();

    void Update_Tax_Percentage();
};